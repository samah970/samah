-- noinspection SqlNoDataSourceInspectionForFile
INSERT INTO entries (COMMENT, USER) VALUES ('Great Comment', 'john');
INSERT INTO entries (COMMENT, USER) VALUES ('Me Too!', 'jane');
INSERT INTO entries (COMMENT, USER) VALUES ('I agree.', 'alice');
INSERT INTO entries (COMMENT, USER) VALUES ('Thanks for the add.', 'john');
INSERT INTO entries (COMMENT, USER) VALUES ('yaas.', 'samah');